const shopkeeperInventory = [
  { id: "apple", quantity: 10 },
  { id: "fish", quantity: 5 },
  { id: "catfish", quantity: 3 },
  { id: "full_restore", quantity: 1},
];

export default shopkeeperInventory;