<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="beach_tiles" tilewidth="32" tileheight="32" tilecount="180" columns="20">
 <image source="../Tilesets/beach_tiles.png" width="640" height="288"/>
</tileset>
