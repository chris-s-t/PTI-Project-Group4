<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="midcentury_modern_furnitureset" tilewidth="32" tileheight="32" tilecount="270" columns="18">
 <image source="../Tilesets/midcentury_modern_furnitureset.png" width="576" height="480"/>
</tileset>
