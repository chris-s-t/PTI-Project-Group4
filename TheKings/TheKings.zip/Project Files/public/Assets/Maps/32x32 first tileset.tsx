<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="32x32 first tileset" tilewidth="32" tileheight="32" tilecount="300" columns="30">
 <image source="../Tilesets/32x32 first tileset.png" width="960" height="320"/>
</tileset>
