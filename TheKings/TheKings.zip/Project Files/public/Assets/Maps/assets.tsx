<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="assets" tilewidth="32" tileheight="32" tilecount="72" columns="8">
 <image source="../Tilesets/assets.png" width="256" height="288"/>
</tileset>
