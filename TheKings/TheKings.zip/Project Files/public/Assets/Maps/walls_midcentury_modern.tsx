<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="walls_midcentury_modern" tilewidth="32" tileheight="32" tilecount="324" columns="18">
 <image source="../Tilesets/walls_midcentury_modern.png" width="576" height="576"/>
</tileset>
