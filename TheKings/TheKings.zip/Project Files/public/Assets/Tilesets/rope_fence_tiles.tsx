<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="rope_fence_tiles" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="rope_fence_tiles.png" width="128" height="128"/>
</tileset>
